KiemHiep – Chỉnh sửa resource pack cho boss CustomModelData
========================================================

ĐÃ SỬA:
------
1. Thêm item override cho carved_pumpkin (helmet boss):
   - assets/minecraft/models/item/carved_pumpkin.json
   - Overrides custom_model_data: 1001, 1002, 1003, 1004

2. Thêm item model cho từng ID (hiển thị trên đầu mob):
   - head_boss_1001/1002/1003/1004.json đều dùng texture entity/zombie/zombie_boss (đã có)
   - Có thể đổi layer0 trong từng file để dùng texture riêng cho Wither/EnderDragon/WitherSkeleton

3. Sửa entity/zombie/zombie_boss.json: texture từ kiemhiep: sang minecraft:
   (pack không có namespace kiemhiep nên phải dùng minecraft:)

CẦN LÀM THÊM (tùy chọn):
-------------------------
- Muốn boss Wither/EnderDragon/WitherSkeleton khác zombie: thêm texture PNG tương ứng rồi sửa layer0 trong head_boss_1002/1003/1004.json.

ĐÓNG GÓI LẠI:
-------------
Nén thư mục ZombieGirls1.4_extract (chọn toàn bộ file bên trong: pack.mcmeta, pack.png, assets) thành ZIP rồi dùng URL đó trong dungeon.yml.
